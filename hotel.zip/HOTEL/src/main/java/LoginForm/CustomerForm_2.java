/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package LoginForm;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import java.time.LocalDate;
import java.util.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Κατερίνα Σφακιανού
 */
public class CustomerForm_2 extends javax.swing.JFrame {

    public CustomerForm_2() {
        initComponents();
    }
    
    public String name;
    public String fullnameText = null;
    public String usernameText = null;
    public String emailText = null;
    public String phoneText = null;
    public String addressText = null;
    public String genderValue = null;
    public String nationalityText = null;
    Date birthdayDate = null;
    
    CustomerForm_2(String name)
    {
        this(); // Καλεί τον προκαθορισμένο κατασκευαστή
        this.name = name;
        Welcome.setText("Hello, "+name);
        
        // Θέτει την ελάχιστη επιλέξιμη ημερομηνία στα πεδία checkin και checkout
        Date date = new Date();
        checkin.setMinSelectableDate(date);
        checkout.setMinSelectableDate(date);
        
        // Αποκρύπτει ορισμένα UI στοιχεία
        jLabel15.setVisible(false);
        carnumber.setVisible(false);
        jSeparator15.setVisible(false);
        usernameText=this.name;
        //System.out.println("username"+usernameText);
        
        try
        {
            // Φόρτωση του JDBC driver και δημιουργία σύνδεσης με τη βάση δεδομένων
            Class.forName("com.mysql.jdbc.Driver");
            String url ="jdbc:mysql://localhost/hotel";
            String user1 = "root";
            String password1 = "";
            Connection con = DriverManager.getConnection(url,user1,password1);
            
            // Δημιουργία statement για εκτέλεση SQL ερωτημάτων
            Statement stm = con.createStatement();
            
            // Εκτέλεση ερωτήματος για την ανάκτηση των στοιχείων του χρήστη με βάση το USERNAME
            ResultSet rs = stm.executeQuery("select * from users where USERNAME = '"+usernameText+"'");
            
            Date dates = null;
            while (rs.next()) {
                // Θέτει τιμές στα UI στοιχεία χρησιμοποιώντας τα ανακτηθέντα δεδομένα
                // Set the values of UI components using the retrieved data
                fullname.setText(rs.getString(2));
                //System.out.println(rs.getString(2)+"name");
                phone.setText(rs.getString(4));
                //System.out.println(rs.getString(4)+"phone");

                nationality.setText(rs.getString(10));
                //System.out.println(rs.getString(10)+"nation");
                email.setText(rs.getString(3));
                //System.out.println(rs.getString(3)+"email");

                address.setText(rs.getString(5));
                //System.out.println(rs.getString(5)+"address");

                // Ανάκτηση της μορφής ημερομηνίας από τη βάση δεδομένων
                String dateFormat = rs.getString(11); // get the date format from the SQL database
                //System.out.println(rs.getString(11)+"birthdate");

                dates = new SimpleDateFormat("yyyy-MM-dd").parse(dateFormat);
                birthday.setDate(dates);
                
                // Έλεγχος για το φύλο και επιλογή της αντίστοιχης επιλογής στη λίστα φύλου
                if(rs.getString(9).equals("Θηλυκό")){
                    gender.setSelectedIndex(1);
                }
                else if(rs.getString(9).equals("Αρσενικό")){
                    gender.setSelectedIndex(0);
                }
                //System.out.println(rs.getString(9)+"gender");
                
            }
 
            // Απόκρυψη πεδίου αριθμού δωματίου
            roomnumber.setVisible(false);
            
        }catch(Exception e)
        {
            System.out.println(e);
        }

    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Welcome = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        reservation = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        allreservations = new javax.swing.JButton();
        userchange = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        LogOut = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        pricenight = new javax.swing.JLabel();
        roomnumber = new javax.swing.JComboBox<>();
        roomtype = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        checkin = new com.toedter.calendar.JDateChooser();
        checkout = new com.toedter.calendar.JDateChooser();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator10 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        jLabel13 = new javax.swing.JLabel();
        paymentmethod = new javax.swing.JComboBox<>();
        jSeparator14 = new javax.swing.JSeparator();
        jLabel15 = new javax.swing.JLabel();
        carnumber = new javax.swing.JTextField();
        jSeparator15 = new javax.swing.JSeparator();
        fullname = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        nationality = new javax.swing.JTextField();
        gender = new javax.swing.JComboBox<>();
        email = new javax.swing.JLabel();
        address = new javax.swing.JTextField();
        birthday = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(74, 31, 61));

        Welcome.setFont(new java.awt.Font("Segoe UI", 3, 20)); // NOI18N
        Welcome.setText("jLabel1");
        Welcome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                WelcomeFocusGained(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("X");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 30)); // NOI18N
        jLabel1.setText("Hotel Managment Πίνακας Πελάτη (Δημιουργία Κράτησης)");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(Welcome, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(379, 379, 379)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(Welcome))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(74, 31, 61));

        reservation.setText("Κράτηση");

        cancel.setText("Ακύρωση");
        cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelMouseClicked(evt);
            }
        });
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });

        allreservations.setText("Όλες οι Κρατήσεις");
        allreservations.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                allreservationsMouseClicked(evt);
            }
        });
        allreservations.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                allreservationsActionPerformed(evt);
            }
        });

        userchange.setText("Επεξεργασία Στοιχείων");
        userchange.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                userchangeMouseClicked(evt);
            }
        });
        userchange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userchangeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(reservation, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(cancel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(allreservations, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(userchange, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(reservation)
                .addGap(180, 180, 180)
                .addComponent(cancel)
                .addGap(123, 123, 123)
                .addComponent(allreservations)
                .addGap(109, 109, 109)
                .addComponent(userchange))
        );

        jPanel3.setBackground(new java.awt.Color(186, 79, 84));

        LogOut.setText("Logout");
        LogOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogOutMouseClicked(evt);
            }
        });
        LogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogOutActionPerformed(evt);
            }
        });

        jLabel3.setText("Ονοματεπώνυμο");

        jLabel4.setText("Τηλέφωνο");

        jLabel5.setText("Εθνικότητα");

        jLabel6.setText("Φύλο");

        jLabel7.setText("Email");

        jLabel8.setText("Διεύθυνση");

        jLabel9.setText("CheckIn");

        jLabel10.setText("CheckOut");

        jLabel11.setText("Τύπος Δωματίου");

        jLabel12.setText("Αριθμός Δωματίου");

        jLabel14.setText("Τιμή ανά ημέρα");

        jButton1.setText("Κράτηση");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        roomnumber.setBackground(new java.awt.Color(186, 79, 84));
        roomnumber.setBorder(null);
        roomnumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomnumberActionPerformed(evt);
            }
        });

        roomtype.setBackground(new java.awt.Color(186, 79, 84));
        roomtype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Μονόκλινο", "Δίκλινο", "Οικογενειακό δωμάτιο", "Σουΐτα" }));
        roomtype.setBorder(null);
        roomtype.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomtypeActionPerformed(evt);
            }
        });

        jLabel19.setText("Ημερομηνία Γέννησης");

        checkin.setBackground(new java.awt.Color(186, 79, 84));

        checkout.setBackground(new java.awt.Color(186, 79, 84));

        jLabel13.setText("Τρόπος Πληρωμής");

        paymentmethod.setBackground(new java.awt.Color(186, 79, 84));
        paymentmethod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ΜΕΤΡΗΤΑ", "ΚΑΡΤΑ" }));
        paymentmethod.setBorder(null);
        paymentmethod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymentmethodActionPerformed(evt);
            }
        });

        jLabel15.setText("Αριθμός Κάρτας");

        carnumber.setBackground(new java.awt.Color(186, 79, 84));
        carnumber.setText("jTextField1");
        carnumber.setBorder(null);

        fullname.setText("jLabel16");

        phone.setBackground(new java.awt.Color(186, 79, 84));
        phone.setText("jTextField1");
        phone.setBorder(null);

        nationality.setBackground(new java.awt.Color(186, 79, 84));
        nationality.setText("jTextField2");
        nationality.setBorder(null);

        gender.setBackground(new java.awt.Color(186, 79, 84));
        gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Αρσενικό", "Θηλυκό", " " }));
        gender.setBorder(null);

        email.setText("jLabel16");

        address.setBackground(new java.awt.Color(186, 79, 84));
        address.setText("jTextField2");
        address.setBorder(null);

        birthday.setBackground(new java.awt.Color(186, 79, 84));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator7, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE)
                            .addComponent(birthday, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator6)
                            .addComponent(jSeparator1)
                            .addComponent(jSeparator4)
                            .addComponent(jSeparator5)
                            .addComponent(fullname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(phone)
                            .addComponent(jSeparator2)
                            .addComponent(email, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(address)
                            .addComponent(gender, javax.swing.GroupLayout.Alignment.TRAILING, 0, 226, Short.MAX_VALUE)
                            .addComponent(nationality)
                            .addComponent(jSeparator3))))
                .addGap(68, 68, 68)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel14)
                            .addComponent(jLabel11)
                            .addComponent(jLabel10)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator13)
                            .addComponent(pricenight, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator11)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(roomnumber, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jSeparator10)
                                    .addComponent(checkin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jSeparator8)
                                    .addComponent(checkout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jSeparator9, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(roomtype, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel15))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(carnumber)
                            .addComponent(jSeparator15)
                            .addComponent(paymentmethod, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jSeparator14)))))
                .addGap(498, 498, 498))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LogOut)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(fullname))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(jLabel10))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addGap(27, 27, 27)
                        .addComponent(jLabel6))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel9)
                            .addComponent(checkin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(4, 4, 4)
                        .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(checkout, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(roomtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(roomnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pricenight)
                            .addComponent(jLabel14))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator13, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel13)
                                    .addComponent(paymentmethod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(nationality, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(email)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jSeparator14, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(carnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator15, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(birthday, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(LogOut))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void LogOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogOutMouseClicked
        Login log = new Login();
        log.show();
        dispose();
    }//GEN-LAST:event_LogOutMouseClicked

    private void WelcomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_WelcomeFocusGained
        
    }//GEN-LAST:event_WelcomeFocusGained

    private void LogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogOutActionPerformed
        Login log = new Login();
        log.show();
        dispose();
    }//GEN-LAST:event_LogOutActionPerformed

    private void roomtypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomtypeActionPerformed
        // Εμφανίζει το πεδίο roomnumber
        roomnumber.setVisible(true);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost/hotel";
            String user1 = "root";
            String password1 = "";
            Connection con = DriverManager.getConnection(url, user1, password1);
            
            Statement stm = con.createStatement();
            String rtype = roomtype.getSelectedItem().toString();

            // Remove all items from the roomnumber JComboBox
            roomnumber.removeAllItems();
            pricenight.setText("");
            ResultSet rs = stm.executeQuery("SELECT RoomNumber,PricePerNight FROM rooms where RoomType = '" + rtype + "' and Availability = true");

            // Create a DefaultComboBoxModel and add the data from the ResultSet
            DefaultComboBoxModel model = new DefaultComboBoxModel();
            while (rs.next()) {
                model.addElement(rs.getString("RoomNumber"));
                pricenight.setText(rs.getString("PricePerNight"));
            }
            roomnumber.setModel(model);

        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_roomtypeActionPerformed

    private void roomnumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomnumberActionPerformed
        try {
            // Φόρτωση του JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
            // Σύνδεση με τη βάση δεδομένων
            String url = "jdbc:mysql://localhost/hotel";
            String user1 = "root";
            String password1 = "";
            Connection con = DriverManager.getConnection(url, user1, password1);
            
            // Δημιουργία Statement
            Statement stm = con.createStatement();
            // Επιλογή του αριθμού δωματίου από το JComboBox
            String rnumber = roomnumber.getSelectedItem().toString();

            // Αφαίρεση όλων των στοιχείων από το JComboBox roomnumber
            pricenight.setText("");
            // Εκτέλεση ερωτήματος για να λάβουμε την τιμή ανά διανυκτέρευση για το επιλεγμένο δωμάτιο
            ResultSet rs = stm.executeQuery("SELECT PricePerNight FROM rooms where RoomNumber = '" + rnumber + "' and Availability = true");

            // Δημιουργία DefaultComboBoxModel και προσθήκη των δεδομένων από το ResultSet
            while (rs.next()) {
                pricenight.setText(rs.getString("PricePerNight"));
                                
            }
            
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_roomnumberActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Έλεγχος για τη συμπλήρωση των απαραίτητων πεδίων
        if(phone.getText().trim().isEmpty() && nationality.getText().trim().isEmpty() && address.getText().trim().isEmpty() && gender.getSelectedIndex() == -1 && birthday.getDate() == null && checkin.getDate() == null && checkout.getDate() == null && roomtype.getSelectedIndex() == -1 && roomnumber.getSelectedIndex() == -1 && paymentmethod.getSelectedIndex() == -1 ){
            JOptionPane.showMessageDialog(null, "Όλα τα πεδία είναι κενά");
        }
        else if(phone.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Το πεδίο τηλεφώνου είναι κενό");
        }
        else if(nationality.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Το πεδίο εθνικότητας είναι κενό");        
        }
        else if(address.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Το πεδίο διεύθυνσης είναι κενό");        
        }
        else if(gender.getSelectedIndex() == -1){
            JOptionPane.showMessageDialog(null, "Το πεδίο φύλου είναι κενό");;        
        }
        else if(birthday.getDate() == null){
            JOptionPane.showMessageDialog(null, "Το πεδίο γενεθλίων είναι κενό");        
        }
        else if(checkin.getDate() == null){
            JOptionPane.showMessageDialog(null, "Το πεδίο ημερομηνίας check-in είναι κενό");       
        }
        else if(checkout.getDate() == null){
            JOptionPane.showMessageDialog(null, "Το πεδίο ημερομηνίας check-out είναι κενό");        
        }
        else if(roomtype.getSelectedIndex() == -1){
            JOptionPane.showMessageDialog(null, "Το πεδίο τύπου δωματίου είναι κενό");        
        }
        else if(roomnumber.getSelectedIndex() == -1){
            JOptionPane.showMessageDialog(null, "Το πεδίο αριθμού δωματίου είναι κενό");        
        }
        else if(paymentmethod.getSelectedIndex() == -1){
            JOptionPane.showMessageDialog(null, "Το πεδίο μεθόδου πληρωμής είναι κενό");        
        }
        else{
            // Εάν η επιλογή πληρωμής είναι "ΚΑΡΤΑ", ελέγχει το πεδίο αριθμού κάρτας
            if(paymentmethod.getSelectedItem().toString().equals("ΚΑΡΤΑ")){
                if(carnumber.getText().trim().isEmpty()){
                    JOptionPane.showMessageDialog(null, "Το πεδίο αριθμού κάρτας είναι κενό");; 
                    return; // Επιστροφή χωρίς να προχωρήσει στην κράτηση
                }
            }
            // Εμφανίζει ένα παράθυρο επιβεβαίωσης για την κράτηση
            int result = JOptionPane.showConfirmDialog(null, "Θέλετε να κάνετε κράτηση γι' αυτό το δωμάτιο;", "Μήνυμα", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                
                try {
                    // Σύνδεση με τη βάση δεδομένων
                    Class.forName("com.mysql.jdbc.Driver");
                    String url = "jdbc:mysql://localhost/hotel";
                    String user1 = "root";
                    String password1 = "";
                    Connection con = DriverManager.getConnection(url, user1, password1);
                    Statement stm = con.createStatement();
                    
                    // Ενημέρωση των πεδίων του χρήστη
                    String query = "UPDATE users SET PHONE = ?, NATIONALITY = ?, GENDER = ?, ADDRESS = ?, BIRTHDAY = ? WHERE USERNAME = ?";
                    PreparedStatement pstmt = con.prepareStatement(query);
                    pstmt.setString(1, phone.getText());
                    pstmt.setString(2, nationality.getText());
                    pstmt.setString(3, gender.getSelectedItem().toString());
                    pstmt.setString(4, address.getText());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String birthdate = sdf.format(birthday.getDate());
                    pstmt.setString(5, birthdate);
                    pstmt.setString(6, usernameText);
                    pstmt.executeUpdate();
                    
                    // Ανάκτηση του ID του χρήστη
                    ResultSet rs = stm.executeQuery("SELECT ID FROM users where USERNAME = '" + usernameText + "'");
                    int id=0;
                    while (rs.next()) {
                       id=rs.getInt(1);
                    }
                    
                    // Εισαγωγή κράτησης
                    String query2 = "INSERT INTO reservations (UserID, RoomNumber, CheckInDate, CheckOutDate) VALUES(?, ?, ?, ?)";
                    PreparedStatement pstmt2 = con.prepareStatement(query2);
                    pstmt2.setInt(1,id);
                    pstmt2.setString(2,roomnumber.getSelectedItem().toString());
                    String checkInDate = sdf.format(checkin.getDate());
                    pstmt2.setString(3,checkInDate);
                    String checkOutDate = sdf.format(checkout.getDate());
                    pstmt2.setString(4,checkOutDate);
                    pstmt2.executeUpdate();
                    
                    // Ενημέρωση της διαθεσιμότητας του δωματίου
                    String query3 = "UPDATE rooms SET Availability = false WHERE RoomNumber = ?";
                    PreparedStatement pstmt3 = con.prepareStatement(query3);
                    pstmt3.setString(1, roomnumber.getSelectedItem().toString());
                    pstmt3.executeUpdate();
                    //System.out.println(id+" id");
                    
                    // Ανάκτηση του ID της κράτησης
                    rs = stm.executeQuery("SELECT ReservationID FROM reservations where UserID= '"+id+"'");
                    int reservationID=0;
                    while (rs.next()) {
                        reservationID = rs.getInt(1);
                    }
                    //System.out.println(reservationID+" reservations id");
                    // Εισαγωγή πληρωμής
                    String query4 = "INSERT INTO payments (ReservationID, PaymentMethod, CardNumber) VALUES(?, ?, ?)";
                    PreparedStatement pstmt4 = con.prepareStatement(query4);
                    pstmt4.setInt(1,reservationID);
                    pstmt4.setString(2,paymentmethod.getSelectedItem().toString());
                    if(paymentmethod.getSelectedItem().toString().equals("ΚΑΡΤΑ"))
                        pstmt4.setString(3,carnumber.getText());
                    else
                        pstmt4.setString(3,"");

                    pstmt4.executeUpdate();
                    String sql1 = "DROP EVENT IF EXISTS update_room_availability";
                    stm.execute(sql1);
                    String sql = "CREATE EVENT update_room_availability ON SCHEDULE EVERY 1 DAY DO UPDATE rooms SET Availability = true WHERE RoomNumber IN (SELECT RoomNumber FROM reservations WHERE CheckOutDate < CURDATE())";
                    stm.execute(sql);
                    
                    // Γράψιμο ενός pdf αρχείου δηλαδή της απόδειξης
                    Document document = new Document();
                    PdfWriter.getInstance(document, new FileOutputStream("ReservationInfo.pdf"));
                    document.open();

                    // Load a system-installed Greek font
                    BaseFont greekFont = BaseFont.createFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);

                    // Create a font object using the Greek font
                    Font contentFont = new Font(greekFont, 12);
                    document.add(new Paragraph("Απόδειξη Κράτησης", contentFont));
                    document.add(new Paragraph("Ονοματεπώνυμο: " + fullname.getText(), contentFont));
                    document.add(new Paragraph("Check-in: " + checkInDate, contentFont));
                    document.add(new Paragraph("Check-out: " + checkOutDate, contentFont));
                    document.add(new Paragraph("Αριθμός δωματίου: " + roomnumber.getSelectedItem().toString(), contentFont));
                    document.add(new Paragraph("Τύπος Δωματίου: " + roomtype.getSelectedItem().toString(), contentFont));

                    Date checkinDate = checkin.getDate();
                    Date checkoutDate = checkout.getDate();
                    // Convert Date objects to LocalDate
                    LocalDate checkIn = checkinDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    LocalDate checkOut = checkoutDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

                    long daysBetween = ChronoUnit.DAYS.between(checkIn, checkOut);
                    if(daysBetween==0){
                        daysBetween=1;
                    }
                    BigDecimal pricePerNight = new BigDecimal(pricenight.getText());
                    BigDecimal totalCost = pricePerNight.multiply(BigDecimal.valueOf(daysBetween));
                    document.add(new Paragraph("Μέρες Διαμονής: "+daysBetween, contentFont));
                    document.add(new Paragraph("Συνολικό Κόστος: "+totalCost, contentFont));
                    document.add(new Paragraph("Μέθοδος Πληρωμής: "+paymentmethod.getSelectedItem().toString(), contentFont));
                    document.close();
                    JOptionPane.showMessageDialog(null, "Η κράτηση έγινε με επιτυχία");
                    new CustomerForm_2(name).setVisible(true);
                    dispose();
                    
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            
        }
            
    }//GEN-LAST:event_jButton1ActionPerformed

    private void paymentmethodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymentmethodActionPerformed
        // Ελέγχει το επιλεγμένο στοιχείο στο JComboBox paymentmethod
        if(paymentmethod.getSelectedItem().toString().equals("ΚΑΡΤΑ")){
            // Εμφανίζει τα σχετικά UI στοιχεία για την πληρωμή με κάρτα
            jLabel15.setVisible(true);
            carnumber.setText("");
            carnumber.setVisible(true);
            jSeparator15.setVisible(true);
            
        }
        else{
            // Αποκρύπτει τα σχετικά UI στοιχεία για την πληρωμή με κάρτα
            jLabel15.setVisible(false);
            carnumber.setVisible(false);
            jSeparator15.setVisible(false);
        }
    }//GEN-LAST:event_paymentmethodActionPerformed

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        new CustomerForm_3(name).setVisible(true);
        dispose();
    }//GEN-LAST:event_cancelActionPerformed

    private void allreservationsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_allreservationsActionPerformed
        new CustomerForm_4(name).setVisible(true);
        dispose();
    }//GEN-LAST:event_allreservationsActionPerformed

    private void userchangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userchangeActionPerformed
        new CustomerForm_5(name).setVisible(true);
        dispose();
    }//GEN-LAST:event_userchangeActionPerformed

    private void cancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelMouseClicked
        new CustomerForm_3(name).setVisible(true);
        dispose();
    }//GEN-LAST:event_cancelMouseClicked

    private void allreservationsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_allreservationsMouseClicked
        new CustomerForm_4(name).setVisible(true);
        dispose();
    }//GEN-LAST:event_allreservationsMouseClicked

    private void userchangeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userchangeMouseClicked
        new CustomerForm_5(name).setVisible(true);
        dispose();
    }//GEN-LAST:event_userchangeMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminForm_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminForm_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminForm_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminForm_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerForm_2.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LogOut;
    private javax.swing.JLabel Welcome;
    private javax.swing.JTextField address;
    private javax.swing.JButton allreservations;
    private com.toedter.calendar.JDateChooser birthday;
    private javax.swing.JButton cancel;
    private javax.swing.JTextField carnumber;
    private com.toedter.calendar.JDateChooser checkin;
    private com.toedter.calendar.JDateChooser checkout;
    private javax.swing.JLabel email;
    private javax.swing.JLabel fullname;
    private javax.swing.JComboBox<String> gender;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextField nationality;
    private javax.swing.JComboBox<String> paymentmethod;
    private javax.swing.JTextField phone;
    private javax.swing.JLabel pricenight;
    private javax.swing.JButton reservation;
    private javax.swing.JComboBox<String> roomnumber;
    private javax.swing.JComboBox<String> roomtype;
    private javax.swing.JButton userchange;
    // End of variables declaration//GEN-END:variables

    private static class setVisible {

        public setVisible(boolean b) {
        }
    }
}
